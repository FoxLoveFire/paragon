#include "gui.hpp"
#include "../../../external/imgui/imgui.h"

void GUI::Render() {
    ImGui::Begin("Main Window");
    if (ImGui::BeginTabBar("Tabs")) {
        if (ImGui::BeginTabItem("General")) {
            ImGui::BeginChild("Subtabs", ImVec2(150, 0), true);
            ImGui::Selectable("Settings");
            ImGui::Selectable("Visuals");
            ImGui::EndChild();
            ImGui::SameLine();
            ImGui::BeginChild("Groupboxes");
            ImGui::Text("Configuration");
            ImGui::EndChild();
            ImGui::EndTabItem();
        }
        ImGui::EndTabBar();
    }
    ImGui::End();
}