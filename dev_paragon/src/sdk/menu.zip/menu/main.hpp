#pragma once
#include <string>
#include <map>
#include "../../../external/imgui/imgui.h"
#include "../../../globals.h"

struct CfgVar {
    bool b = false;
    int i = 0;
    float f = 0.0f;
    std::string s = "";
    ImVec4 c = { 1.0f, 1.0f, 1.0f, 1.0f };
};

namespace Menu {
    extern std::map<std::string, CfgVar> cfg;
    void Initialize();
    void Render();
}

namespace GUI {
    void Render();
}