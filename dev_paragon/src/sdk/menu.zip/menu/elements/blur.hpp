#pragma once
#include <d3d11.h>

namespace Blur {
    void Initialize(ID3D11Device* device);
    void Render(ID3D11DeviceContext* ctx, ID3D11ShaderResourceView* backgroundSRV, ID3D11RenderTargetView* rtv);
    void Shutdown();
}