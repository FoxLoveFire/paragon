#include "blur.hpp"
#include "blur_x.hpp"
#include "blur_y.hpp"

namespace Blur {
    ID3D11PixelShader* pBlurXShader = nullptr;
    ID3D11PixelShader* pBlurYShader = nullptr;

    void Initialize(ID3D11Device* device) {
        device->CreatePixelShader(blur_x_bytecode, sizeof(blur_x_bytecode), nullptr, &pBlurXShader);
        device->CreatePixelShader(blur_y_bytecode, sizeof(blur_y_bytecode), nullptr, &pBlurYShader);
    }

    void Render(ID3D11DeviceContext* ctx, ID3D11ShaderResourceView* backgroundSRV, ID3D11RenderTargetView* rtv) {
        ctx->OMSetRenderTargets(1, &rtv, nullptr);
        ctx->PSSetShaderResources(0, 1, &backgroundSRV);
        ctx->PSSetShader(pBlurXShader, nullptr, 0);
        ctx->Draw(3, 0);
        ctx->PSSetShader(pBlurYShader, nullptr, 0);
        ctx->Draw(3, 0);
    }

    void Shutdown() {
        if (pBlurXShader) { pBlurXShader->Release(); pBlurXShader = nullptr; }
        if (pBlurYShader) { pBlurYShader->Release(); pBlurYShader = nullptr; }
    }
}