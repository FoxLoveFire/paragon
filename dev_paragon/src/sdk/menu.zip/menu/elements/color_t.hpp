#pragma once

struct color_t {
    float r, g, b, a;
    color_t(float _r, float _g, float _b, float _a) : r(_r), g(_g), b(_b), a(_a) {}
};